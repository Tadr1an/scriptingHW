CREATE TABLE Client_A_Contacts 
(
     first_name varchar(100),
     last_name varchar(100),
     city varchar(50),
     county varchar(50),
     zip varchar(50),
     officePhone varchar(50),
     mobilePhone varchar(50)
);